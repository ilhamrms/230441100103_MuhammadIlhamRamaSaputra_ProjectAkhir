
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Home;

import java.sql.DriverManager;

/**
 *
 * @author Usher
 */
//public class Koneksi {
//    private static java.sql.Connection koneksi;
//    
//    public static java.sql.Connection getKoneksi() {
//        if (koneksi == null) {
//            try{
//                String url = "jdbc:mysql://localhost:3306/absensi";
//                String user = "root";
//                String pass = "";
//                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
//                koneksi = DriverManager.getConnection(url, user, pass);
//                System.out.println("Connection Successfully");
//            }catch (Exception e) {
//                System.out.println("Error");
//            }
//        }
//        return koneksi;
//    }
//    public static void main(String[] args) {
//        getKoneksi();
//    }
//    
//}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {
    private static Connection koneksi;

    // Method untuk mendapatkan koneksi
    public static Connection getKoneksi() {
        if (koneksi == null) {
            try {
                // URL, username, dan password untuk koneksi
                String url = "jdbc:mysql://localhost:3306/absensi"; // Ganti "absensi" dengan nama database Anda
                String user = "root"; // Ganti "root" dengan username MySQL Anda
                String pass = ""; // Ganti dengan password MySQL Anda

                // Register driver MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");
                koneksi = DriverManager.getConnection(url, user, pass);
                System.out.println("Connection successfully established.");
            } catch (ClassNotFoundException e) {
                System.err.println("Driver tidak ditemukan: " + e.getMessage());
            } catch (SQLException e) {
                System.err.println("Koneksi gagal: " + e.getMessage());
            }
        }
        return koneksi;
    }

    // Method main untuk testing koneksi
    public static void main(String[] args) {
        Connection conn = getKoneksi();
        if (conn != null) {
            System.out.println("Koneksi berhasil digunakan.");
        } else {
            System.out.println("Koneksi gagal.");
        }
    }
}

